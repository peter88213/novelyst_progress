"""A daily progress log viewer plugin for noveltree.

Requires Python 3.6+
Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/nv_progress
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import os
from pathlib import Path
import webbrowser
from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
import sys
import tkinter as tk


def set_icon(widget, icon='logo', path=None, default=True):
    if path is None:
        path = os.path.dirname(sys.argv[0])
        if not path:
            path = '.'
        path = f'{path}/icons'
    try:
        pic = tk.PhotoImage(file=f'{path}/{icon}.png')
        widget.iconphoto(default, pic)
    except:
        return False

    return True

import gettext
import locale

__all__ = ['Error',
           '_',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'APPLICATION',
           'PLUGIN',
           ]


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('nv_progress', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Daily progress log')
PLUGIN = f'{APPLICATION} plugin v2.2.0'
from datetime import date
from tkinter import ttk


class ProgressViewer(tk.Toplevel):
    _KEY_QUIT_PROGRAM = ('<Control-q>', 'Ctrl-Q')

    def __init__(self, plugin, controller):
        self._controller = controller
        self._plugin = plugin
        super().__init__()

        self.geometry(self._plugin.kwargs['window_geometry'])
        self.lift()
        self.protocol("WM_DELETE_WINDOW", self.on_quit)
        self.bind(self._KEY_QUIT_PROGRAM[0], self.on_quit)

        columns = (
            'date',
            'wordCount',
            'wordCountDelta',
            'totalWordCount',
            'totalWordCountDelta',
            'spacer',
            )
        self.tree = ttk.Treeview(self, selectmode='none', columns=columns)
        scrollY = ttk.Scrollbar(self.tree, orient='vertical', command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollY.set)
        scrollY.pack(side='right', fill='y')
        self.tree.pack(fill='both', expand=True)
        self.tree.heading('date', text=_('Date'))
        self.tree.heading('wordCount', text=_('Words total'))
        self.tree.heading('wordCountDelta', text=_('Daily'))
        self.tree.heading('totalWordCount', text=_('With unused'))
        self.tree.heading('totalWordCountDelta', text=_('Daily'))
        self.tree.column('#0', width=0)
        self.tree.column('date', anchor='center', width=self._plugin.kwargs['date_width'], stretch=False)
        self.tree.column('wordCount', anchor='center', width=self._plugin.kwargs['wordcount_width'], stretch=False)
        self.tree.column('wordCountDelta', anchor='center', width=self._plugin.kwargs['wordcount_delta_width'], stretch=False)
        self.tree.column('totalWordCount', anchor='center', width=self._plugin.kwargs['totalcount_width'], stretch=False)
        self.tree.column('totalWordCountDelta', anchor='center', width=self._plugin.kwargs['totalcount_delta_width'], stretch=False)

        self.tree.tag_configure('positive', foreground='black')
        self.tree.tag_configure('negative', foreground='red')
        self.isOpen = True
        self.build_tree()

    def build_tree(self):
        self.reset_tree()
        wcLog = {}

        for wcDate in self._controller.model.wcLog:
            wcLog[wcDate] = self._controller.model.wcLog[wcDate]

        for wcDate in self._controller.model.wcLogUpdate:
            wcLog[wcDate] = self._controller.model.wcLogUpdate[wcDate]

        newCountInt, newTotalCountInt = self._controller.model.count_words()
        newCount = str(newCountInt)
        newTotalCount = str(newTotalCountInt)
        today = date.today().isoformat()
        wcLog[today] = [newCount, newTotalCount]

        lastCount = 0
        lastTotalCount = 0
        for wc in wcLog:
            columns = []
            nodeTags = ()
            countInt = int(wcLog[wc][0])
            countDiffInt = countInt - lastCount
            totalCountInt = int(wcLog[wc][1])
            totalCountDiffInt = totalCountInt - lastTotalCount
            if countDiffInt == 0 and totalCountDiffInt == 0:
                continue

            if countDiffInt > 0:
                nodeTags = ('positive')
            else:
                nodeTags = ('negative')
            columns = [
                wc,
                str(wcLog[wc][0]),
                str(countDiffInt),
                str(wcLog[wc][1]),
                str(totalCountDiffInt),
                ]
            lastCount = countInt
            lastTotalCount = totalCountInt
            startIndex = '0'
            self.tree.insert('', startIndex, iid=wc, values=columns, tags=nodeTags, open=True)

    def on_quit(self, event=None):
        self._plugin.kwargs['window_geometry'] = self.winfo_geometry()
        self._plugin.kwargs['date_width'] = self.tree.column('date', 'width')
        self._plugin.kwargs['wordcount_width'] = self.tree.column('wordCount', 'width')
        self._plugin.kwargs['wordcount_delta_width'] = self.tree.column('wordCountDelta', 'width')
        self._plugin.kwargs['totalcount_width'] = self.tree.column('totalWordCount', 'width')
        self._plugin.kwargs['totalcount_delta_width'] = self.tree.column('totalWordCountDelta', 'width')
        self.destroy()
        self.isOpen = False

    def reset_tree(self):
        for child in self.tree.get_children(''):
            self.tree.delete(child)


SETTINGS = dict(
    window_geometry='510x440',
    date_width=100,
    wordcount_width=100,
    wordcount_delta_width=100,
    totalcount_width=100,
    totalcount_delta_width=100,
)
OPTIONS = {}


class Plugin:
    VERSION = '2.2.0'
    NOVELYST_API = '0.6'
    DESCRIPTION = 'A daily progress log viewer'
    URL = 'https://peter88213.github.io/nv_progress'

    def disable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def enable_menu(self):
        self._ui.toolsMenu.entryconfig(APPLICATION, state='normal')

    def install(self, controller, ui):
        """Add a submenu to the 'Tools' menu.
        
        Positional arguments:
            controller -- reference to the main controller instance of the application.
            ui -- reference to the main view instance of the application.
        """
        self._controller = controller
        self._ui = ui
        self._progress_viewer = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.noveltree/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/progress.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        self._ui.toolsMenu.add_command(label=APPLICATION, command=self._start_viewer)
        self._ui.toolsMenu.entryconfig(APPLICATION, state='disabled')

    def on_close(self):
        self.on_quit()

    def on_quit(self):
        if self._progress_viewer:
            if self._progress_viewer.isOpen:
                self._progress_viewer.on_quit()

        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

    def _start_viewer(self):
        if self._progress_viewer:
            if self._progress_viewer.isOpen:
                self._progress_viewer.lift()
                self._progress_viewer.focus()
                self._progress_viewer.build_tree()
                return

        self._progress_viewer = ProgressViewer(self, self._controller)
        self._progress_viewer.title(f'{self._controller.novel.title} - {PLUGIN}')
        set_icon(self._progress_viewer, icon='wLogo32', default=False)

